package com.example.cscb07groupproject;

public class AdminOperations {
}
